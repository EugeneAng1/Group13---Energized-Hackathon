const express = require('express');
const path = require('path');
const fs = require('fs');
const { createObjectCsvWriter } = require('csv-writer');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// CSV setup
const csvPath = path.join(__dirname, 'foodLog.csv');
const csvWriter = createObjectCsvWriter({
    path: csvPath,
    header: [
        { id: 'food', title: 'food' },
        { id: 'calories', title: 'calories' },
        { id: 'time', title: 'time' }
    ],
    append: true
});

// Load existing CSV
let foodLog = [];
if (fs.existsSync(csvPath)) {
    const data = fs.readFileSync(csvPath, 'utf8');
    const lines = data.split('\n');
    lines.shift(); // remove header
    lines.forEach(line => {
        if (line.trim()) {
            const [food, calories, time] = line.split(',');
            foodLog.push({ food, calories: Number(calories), time });
        }
    });
}

// API routes
app.get('/api/foodlog', (req, res) => {
    res.json(foodLog);
});

app.post('/api/foodlog', async (req, res) => {
    const { food, calories, time } = req.body;

    if (!food || !calories || !time) {
        return res.status(400).json({ message: 'Missing food, calories, or time' });
    }

    const newEntry = { food, calories: Number(calories), time };
    foodLog.push(newEntry);
    await csvWriter.writeRecords([newEntry]);

    res.status(201).json({ message: 'Food entry added', entry: newEntry });
});

// Fallback for / route (optional)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));